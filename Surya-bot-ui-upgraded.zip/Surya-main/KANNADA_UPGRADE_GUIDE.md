# Surya File Store Bot — UI Upgrade (ಕನ್ನಡ)

ಈ upgrade ಮೂಲ Pyrogram project‌ನ welcome screen ಅನ್ನು screenshot‌ನಂತಿರುವ inline menu ಆಗಿ ಬದಲಿಸುತ್ತದೆ. File-link ಮೂಲ logic ಹಾಗೆಯೇ ಉಳಿಸಲಾಗಿದೆ.

## ಹೊಸ home menu
- Upload / Help
- Gen Link, Batch Link
- Premium ಮಾಹಿತಿ button
- Tutorial ಮತ್ತು Help
- Admin commands, Support

## Render environment variables
ಹಳೆಯ variables (`TG_BOT_TOKEN`, `APP_ID`, `API_HASH`, `CHANNEL_ID`, `OWNER_ID`, `DATABASE_URL`) ಉಳಿಸಿ. ಜೊತೆಗೆ:
- `TUTORIAL_URL`: ನಿಮ್ಮ tutorial link
- `SUPPORT_URL`: ನಿಮ್ಮ support group/channel link
- `PREMIUM_TEXT`: Premium/UPI ಮಾಹಿತಿ text
- `START_PIC`: optional banner image URL ಅಥವಾ Telegram file_id

`START_MESSAGE` ನೀಡಿದ್ದರೆ ಅದು config.py default text ಅನ್ನು override ಮಾಡುತ್ತದೆ. Custom look ಬೇಕಾದರೆ Renderನಲ್ಲಿ `START_MESSAGE` ಅನ್ನು delete ಮಾಡಿ ಅಥವಾ update ಮಾಡಿ.

## Deploy
1. ZIP extract ಮಾಡಿ GitHub repositoryಗೆ files push ಮಾಡಿ.
2. Renderನಲ್ಲಿ ಅದೇ repository service ಅನ್ನು redeploy ಮಾಡಿ.
3. Environment variables ಅನ್ನು Render → Environmentನಲ್ಲಿ ಹೊಂದಿಸಿ.
4. Botಗೆ `/start` ಕಳುಹಿಸಿ buttons ಪರಿಶೀಲಿಸಿ.

## ಮುಖ್ಯ ಸೂಚನೆ
ಈ package UI/menu upgrade ಮಾತ್ರ. UPI payment ಸ್ವಯಂ verify ಮಾಡುವ ವ್ಯವಸ್ಥೆ ಇದರಲ್ಲಿ ಇಲ್ಲ; payment ಪರಿಶೀಲಿಸಿ admin ಕೈಯಾರೆ membership activate ಮಾಡಬೇಕು. `TUTORIAL_URL`/`SUPPORT_URL` placeholders ಅನ್ನು ನಿಮ್ಮ ನಿಜವಾದ links‌ನಿಂದ ಬದಲಿಸಿ. Shortener API integration ನಿಮ್ಮ providerನ endpoint/response format ತಿಳಿದ ನಂತರ ಪ್ರತ್ಯೇಕವಾಗಿ ಹೊಂದಿಸಬೇಕು.
